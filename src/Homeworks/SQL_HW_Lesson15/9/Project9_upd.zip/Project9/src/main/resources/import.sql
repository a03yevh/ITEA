INSERT INTO animals (age, name, tail) VALUES (3, 'Dog', true);
